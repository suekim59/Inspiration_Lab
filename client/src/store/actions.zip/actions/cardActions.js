import {
    CONSTANTS
} from '../actions'
import axios from 'axios'

const API_URL = "http://localhost:3001"

export const addCard = (listId, text) => {
    return async (dispatch, getState) => {
        const response = await axios.post(`${API_URL}/card`, {
            "text": text,
            "listId": listId
        })

        dispatch({
            type: CONSTANTS.ADD_CARD,
            payload: {
                "id": response.data.id,
                "text": response.data.text,
                "listId": response.data.list.id
            }
        })
    }
};

export const deleteCard = (id, listId) => {
    return async (dispatch) => {
        const response = await axios.delete(`${API_URL}/card/${id}`)
        if (response.status === 204) {
            dispatch({
                type: CONSTANTS.DELETE_CARD,
                payload: {
                    "id": id,
                    "listId": listId
                }
            })
        }
    }
}

export const editCard = (listId, id, text) => {
    return async (dispatch) => {
        const response = await axios.patch(`${API_URL}/card/${id}`, {
            text
        })
        dispatch({
            type: CONSTANTS.EDIT_CARD,
            payload: {
                "listId": listId,
                "id": response.data.id,
                "text": response.data.text
            }
        })
    }
}

export const sortCard = (droppableIdStart, droppableIdEnd, droppableIndexStart, droppableIndexEnd, draggableId, type) => {
    return async (dispatch) => {

        dispatch({
            type: CONSTANTS.DRAG_HAPPENED,
            payload: {
                droppableIdStart,
                droppableIdEnd,
                droppableIndexStart,
                droppableIndexEnd,
                draggableId,
                type
            }
        })


        const response = await axios.patch(`${API_URL}/card/${droppableIndexStart}`, {
            "listId": parseInt(draggableId.substring(5)),
            "index": droppableIndexEnd
        })
        dispatch({
            type: CONSTANTS.SET_LIST,
            payload: response.data
        })

    }
}