import {
    CONSTANTS
} from '../actions'
import axios from 'axios'

const API_URL = "http://localhost:3001"


export const addList = (title) => {
    return async (dispatch) => {
        const response = await axios.post(`${API_URL}/list`, {
            title
        })
        dispatch({
            type: CONSTANTS.ADD_LIST,
            payload: response.data
        })
    };
};

export const deleteList = (listId) => {
    return async (dispatch) => {
        const response = await axios.delete(`${API_URL}/list/${listId}`)
        if (response.status === 204) {
            dispatch({
                type: CONSTANTS.DELETE_LIST,
                payload: listId
            })
        }
    }
}


export const fetchLists = () => {
    return async (dispatch) => {
        const response = await axios.get(`${API_URL}/list/`)
        dispatch({
            type: CONSTANTS.SET_LIST,
            payload: response.data
        })
    }
}

export const sortList = (droppableIdStart, droppableIdEnd, droppableIndexStart, droppableIndexEnd, draggableId, type) => {
    return async (dispatch) => {
        dispatch({
            type: CONSTANTS.DRAG_HAPPENED,
            payload: {
                droppableIdStart,
                droppableIdEnd,
                droppableIndexStart,
                droppableIndexEnd,
                draggableId,
                type
            }
        })
        const response = await axios.patch(`${API_URL}/list/${droppableIndexStart}`, {
            "index": droppableIndexEnd
        })
        dispatch({
            type: CONSTANTS.SET_LIST,
            payload: response.data
        })
    }
}
